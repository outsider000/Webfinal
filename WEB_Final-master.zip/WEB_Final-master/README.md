# WEB_Final
Under the root of MEANApp:----
npm install
npm start
------Run at localhost:3000

Under the root of socket:----
	nodemon index
